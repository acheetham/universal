var fluid_1_4 = fluid_1_4 || {};
(function ($, fluid) {
    fluid.defaults("fluid.uiOptions.store", {
        gradeNames: ["fluid.littleComponent", "autoInit"],
        defaultSiteSettings: {
            textFont: "default",
            theme: "default",
            textSize: 1,
            lineSpacing: 1,
            layout: false,
            toc: false,
            links: false,
            inputsLarger: false
        }
    });
    fluid.defaults("fluid.cookieStore", {
        gradeNames: ["fluid.uiOptions.store", "autoInit"],
        invokers: {
            fetch: {
                funcName: "fluid.cookieStore.fetch",
                args: ["{cookieStore}.options.cookie.name", "{cookieStore}.options.defaultSiteSettings"]
            },
            save: {
                funcName: "fluid.cookieStore.save",
                args: ["{arguments}.0", "{cookieStore}.options.cookie"]
            }
        },
        cookie: {
            name: "fluid-ui-settings",
            path: "/",
            expires: ""
        }
    });
    fluid.cookieStore.fetch = function (cookieName, defaults) {
        var cookie = document.cookie;
        var cookiePrefix = cookieName + "=";
        var retObj, startIndex, endIndex;
        if (cookie.length > 0) {
            startIndex = cookie.indexOf(cookiePrefix);
            if (startIndex > -1) {
                startIndex = startIndex + cookiePrefix.length;
                endIndex = cookie.indexOf(";", startIndex);
                if (endIndex < startIndex) {
                    endIndex = cookie.length
                }
                retObj = JSON.parse(decodeURIComponent(cookie.substring(startIndex, endIndex)))
            }
        }
        return retObj || defaults
    };
    fluid.cookieStore.assembleCookie = function (cookieOptions) {
        var cookieStr = cookieOptions.name + "=" + cookieOptions.data;
        if (cookieOptions.expires) {
            cookieStr += "; expires=" + cookieOptions.expires
        }
        if (cookieOptions.path) {
            cookieStr += "; path=" + cookieOptions.path
        }
        return cookieStr
    };
    fluid.cookieStore.save = function (settings, cookieOptions) {
        cookieOptions.data = encodeURIComponent(JSON.stringify(settings));
        document.cookie = fluid.cookieStore.assembleCookie(cookieOptions)
    };
    fluid.defaults("fluid.tempStore", {
        gradeNames: ["fluid.uiOptions.store", "autoInit"],
        invokers: {
            fetch: {
                funcName: "fluid.tempStore.fetch",
                args: ["{tempStore}"]
            },
            save: {
                funcName: "fluid.tempStore.save",
                args: ["{arguments}.0", "{tempStore}"]
            }
        },
        finalInitFunction: "fluid.tempStore.finalInit"
    });
    fluid.tempStore.finalInit = function (that) {
        that.model = that.options.defaultSiteSettings
    };
    fluid.tempStore.fetch = function (that) {
        return that.model
    };
    fluid.tempStore.save = function (settings, that) {
        that.model = settings
    }
})(jQuery, fluid_1_4);
