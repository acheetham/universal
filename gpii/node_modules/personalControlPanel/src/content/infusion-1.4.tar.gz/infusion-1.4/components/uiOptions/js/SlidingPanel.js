var fluid_1_4 = fluid_1_4 || {};
(function ($, fluid) {
    fluid.defaults("fluid.slidingPanel", {
        gradeNames: ["fluid.viewComponent", "autoInit"],
        selectors: {
            panel: ".flc-slidingPanel-panel",
            toggleButton: ".flc-slidingPanel-toggleButton"
        },
        strings: {
            showText: "+ Show Display Preferences",
            hideText: "- Hide"
        },
        events: {
            onPanelHide: null,
            onPanelShow: null,
            afterPanelHide: null,
            afterPanelShow: null
        },
        finalInitFunction: "fluid.slidingPanel.finalInit",
        invokers: {
            operateHide: "fluid.slidingPanel.slideUp",
            operateShow: "fluid.slidingPanel.slideDown"
        },
        hideByDefault: true
    });
    fluid.slidingPanel.slideUp = function (element, callback, duration) {
        $(element).slideUp(duration || "400", callback)
    };
    fluid.slidingPanel.slideDown = function (element, callback, duration) {
        $(element).slideDown(duration || "400", callback)
    };
    fluid.slidingPanel.finalInit = function (that) {
        that.showPanel = function () {
            that.events.onPanelShow.fire(that);
            that.locate("toggleButton").text(that.options.strings.hideText);
            that.operateShow(that.locate("panel"), that.events.afterPanelShow.fire)
        };
        that.hidePanel = function () {
            that.events.onPanelHide.fire(that);
            that.locate("toggleButton").text(that.options.strings.showText);
            that.operateHide(that.locate("panel"), that.events.afterPanelHide.fire)
        };
        that.togglePanel = function () {
            if (that.locate("panel").is(":hidden")) {
                that.showPanel()
            } else {
                that.hidePanel()
            }
        };
        that.setPanelHeight = function (newHeight) {
            that.locate("panel").height(newHeight)
        };
        that.locate("toggleButton").click(that.togglePanel);
        if (that.options.hideByDefault) {
            that.locate("toggleButton").text(that.options.strings.showText);
            that.locate("panel").hide()
        }
    }
})(jQuery, fluid_1_4);