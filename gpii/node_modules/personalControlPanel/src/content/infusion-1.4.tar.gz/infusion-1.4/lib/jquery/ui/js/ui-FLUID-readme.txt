The jquery.ui.*.js files in this folder were taken from the 1.8.12 bundle, downloaded Apr. 23, 2011
http://jquery-ui.googlecode.com/files/jquery-ui-1.8.12.zip
